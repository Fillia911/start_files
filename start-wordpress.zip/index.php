<?php get_header(); ?>

<section class="wp_theme-section">
    <div class="container">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>

                <?php if (get_the_title()) : ?>
                    <div class="title-holder">
                        <?php if (is_single()) : ?>
                            <h1><?php the_title(); ?></h1>
                        <?php else : ?>
                            <h1>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h1>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="author-holder">
                    <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                        <?php the_author(); ?>
                    </a>
                </div>

                <div class="content-holder">
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'large')); ?>" alt="<?php the_title_attribute(); ?>">
                    <?php endif; ?>
                    <?php the_content(); ?>
                </div>

                <div class="page_break-holder">
                    <?php wp_link_pages(); ?>
                </div>

                <?php
                ob_start();
                comments_popup_link(
                    'No Comments',
                    '1 Comment',
                    '% Comments'
                );
                $comments_link = trim(ob_get_clean());

                if ($comments_link || is_single()) : ?>
                    <div class="comments-holder">
                        <?php echo $comments_link; ?>
                        <?php if (is_single()) comments_template(); ?>
                    </div>
                <?php endif; ?>

            <?php endwhile; ?>
        <?php else : ?>
            <h2>No posts found.</h2>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>