<?php
/*
Template Name: Homepage
*/

get_header(); 

	get_template_part('template-parts/hero');

get_footer();

?>