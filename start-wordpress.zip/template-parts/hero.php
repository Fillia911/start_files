<?php
$title = get_field('hero_title');
?>

<section class="intro-section">
	<div class="container">

		<?= $title; ?>
		
	</div>
</section>