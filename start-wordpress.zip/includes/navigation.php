<?php
// ===========================
// Register Navigation Menus
// ===========================
add_action('after_setup_theme', function() {
    register_nav_menus([
        'primary' => 'Primary Navigation',
        'footer'  => 'Footer Navigation',
    ]);
});

// ===========================
// Custom Walker for Menu
// ===========================
class Custom_Walker_Nav_Menu extends Walker_Nav_Menu {

    public function start_lvl( &$output, $depth = 0, $args = null ) {
        $output .= '<ul class="menu-children-wrapper">';
    }

    public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {

        $li_classes = [
            'menu-depth-' . ($depth + 1),
        ];

        $output .= '<li class="' . esc_attr(implode(' ', $li_classes)) . '">';

        $link_classes = [];
        if (!empty($item->classes) && is_array($item->classes)) {
            foreach ($item->classes as $class) {
                if (!empty($class)) {
                    $link_classes[] = esc_attr($class);
                }
            }
        }

        $class_attr = $link_classes ? ' class="' . implode(' ', $link_classes) . '"' : '';

        $url = trim($item->url);
        $href = $url !== '' ? esc_url($url) : 'javascript:;';

        $output .= '<a href="' . $href . '"' . $class_attr . '>';
        $output .= esc_html($item->title);
        $output .= '</a>';
    }

    public function end_el( &$output, $item, $depth = 0, $args = null ) {
        $output .= '</li>';
    }
}

/*
Examples:
wp_nav_menu([
    'theme_location' => 'primary',
    'menu_class'     => 'menu-list',
    'container'      => 'nav',
    'walker'         => new Custom_Walker_Nav_Menu(),
]);

wp_nav_menu([
    'theme_location' => 'primary',
    'menu_class'     => 'menu-list',
    'container'      => 'nav',
]);
*/