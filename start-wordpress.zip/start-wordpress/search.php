<?php get_header(); ?>

	<section class="theme_content-section">
		<div class="container">
			<?php if ( have_posts() ) : ?>
				<div class="title-block">
					<h1><?php printf( 'Search Results for: %s', '<span>' . get_search_query() . '</span>' ); ?></h1>
				</div>
				<div class="content-block">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'template-parts/content', get_post_type() ); ?>
					<?php endwhile; ?>
				</div>
				<?php get_template_part( 'template-parts/pager' ); ?>
			<?php else : ?>
				<?php get_template_part( 'template-parts/not_found' ); ?>
			<?php endif; ?>
		</div>
	</section>

<?php get_footer(); ?>