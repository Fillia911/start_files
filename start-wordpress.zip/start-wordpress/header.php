<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php wp_head(); ?>
</head>
<body>
	<div id="wrapper">
		<header id="header">
			<!-- menu -->
			<?php
				wp_nav_menu([
					'container' => '',
					'menu_class' => 'menu-list',
					'theme_location' => 'primary',
					'walker' => new Custom_Walker_Nav_Menu(),
				]);
			?>
			<!-- header text -->
			<?php
			$header_text_01 = get_theme_mod('header_text_01');
			if ( $header_text_01 ): ?>
				<p><?php echo $header_text_01; ?></p>
			<?php endif; ?>
		</header>
		<main id="main">
