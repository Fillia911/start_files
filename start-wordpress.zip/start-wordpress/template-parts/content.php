<div class="post-item" id="post-<?php the_ID(); ?>">
	<div class="title-block">
		<?php if ( is_single() ) :
			the_title( '<h1>', '</h1>' );
		else :
			the_title( '<h2><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif; ?>
		<p class="meta-info">
			<?php custom_date_info(true, true); ?>
			by
			<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ); ?>"><?php the_author(); ?></a>
		</p>
	</div>
	<div class="content-block">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'thumbnail' ); ?>
		<?php endif; ?>
		<?php the_content(); ?>
	</div>
	<?php wp_link_pages(); ?>
	<div class="meta-block">
		<ul>
			<li>Posted in <?php the_category( ', ' ); ?></li>
			<li><?php comments_popup_link( 'No Comments', '1 Comment', '% Comments' ); ?></li>
			<?php if ( has_tag() ) : ?>
				<?php the_tags( '<li>' . 'Tags: ', ', ', '</li>' ); ?>
			<?php endif; ?>
			<?php edit_post_link( 'Edit', '<li>', '</li>' ); ?>
		</ul>
	</div>
</div>