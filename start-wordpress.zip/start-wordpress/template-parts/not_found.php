<div class="not_found-block">
	<div class="title-block">
		<h1>Not Found</h1>
	</div>
	<div class="content-block">
		<p>Sorry, but you are looking for something that isn't here.</p>
		<?php get_search_form(); ?>
	</div>
</div>