<?php
	the_posts_pagination( array(
		'prev_text' => 'Previous page',
		'next_text' => 'Next page',
	) );
?>