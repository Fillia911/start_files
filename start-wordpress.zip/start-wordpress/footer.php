		</main>
		<footer id="footer">
			<!-- social menu -->
			<?php social_icons(); ?>
			<!-- social menu ico -->
			<?php social_icons('icons'); ?>
			<!-- footer text -->
			<?php
			$footer_text_01 = get_theme_mod('footer_text_01');
			if ( $footer_text_01 ): ?>
				<p><?php echo $footer_text_01; ?></p>
			<?php endif; ?>
		</footer>
	</div>

	<?php wp_footer(); ?>
</body>
</html>