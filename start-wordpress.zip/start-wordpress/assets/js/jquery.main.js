(function ($) {

	// Includes

	// Functions

})(jQuery);



// Plugins