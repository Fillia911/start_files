<?php get_header(); ?>

	<section class="theme_content-section">
		<div class="container">
			<div class="content-block">
				<?php while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'template-parts/content', get_post_type() ); ?>
					<?php comments_template(); ?>
				<?php endwhile; ?>
			</div>
		</div>
	</section>

<?php get_footer(); ?>