<?php $sq = get_search_query() ? get_search_query() : 'Enter search terms&hellip;' ?>
<form method="get" class="search-form" action="<?php echo esc_url( home_url() ); ?>">
	<input type="search" name="s" placeholder="<?php echo esc_attr( $sq ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" /><br/><br/>
	<input type="submit" value="Search" />
</form>