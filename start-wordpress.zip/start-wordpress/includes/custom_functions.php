<?php

	// Get posts reading time
	function get_post_reading_time() {
		$content = get_the_content();
		$word_count = str_word_count(strip_tags($content));
		$reading_time = ceil($word_count / 200);
		
		if ($reading_time) {
			echo '<span class="post-reading-time">' . $reading_time . ' min read</span>';
		}
	}

	// Get post categories
	function get_post_categories() {
		$categories_list = get_the_category_list(', ');
		if ($categories_list) {
			echo '<span class="post-categories">' . $categories_list . '</span>';
		}
	}

	// Custom date - June 19th, 2024
	function custom_date_info($show_link = false, $show_time = true) {
		$year  = get_the_date('Y');
		$month = get_the_date('m');
		$day   = get_the_date('d');
		$date_format = 'F jS, Y';

		$archive_type = get_option('eg_date_archive_link_type', 'month');
		switch ($archive_type) {
			case 'year':
				$archive_link = get_year_link($year);
				break;
			case 'day':
				$archive_link = get_day_link($year, $month, $day);
				break;
			default:
				$archive_link = get_month_link($year, $month);
				break;
		}

		$time_string = sprintf(
			'<time class="entry-date published updated" datetime="%1$s">%2$s</time>',
			esc_attr(get_the_date('c')),
			esc_html(date_i18n($date_format, get_the_date('U')))
		);

		if ($show_link) {
			$output = '<a href="' . esc_url($archive_link) . '" rel="bookmark">' . $time_string . '</a>';
		} elseif ($show_time) {
			$output = $time_string;
		} else {
			$output = '';
		}

		echo $output;
	}

	// Clean phone number
	function clean_phone($phone){
		$cleaned_phone = preg_replace('/[^0-9]/', '', $phone);
		echo $cleaned_phone;
	}

?>