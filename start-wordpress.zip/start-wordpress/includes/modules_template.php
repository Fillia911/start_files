<?php

	// Enqueue scripts for drag-and-drop sections
	add_action('admin_enqueue_scripts', function() {

		if ('page' === get_post_type()) {
			wp_enqueue_script('sortablejs', get_template_directory_uri() . '/assets/js/sortablejs.main.js', [], filemtime(get_template_directory() . '/assets/js/sortablejs.main.js'), true);
		}
	});

	// Create metabox
	function custom_sections_meta_box() {
		$template = get_page_template_slug();

		if ('page_modules.php' === $template) {
			add_meta_box(
				'custom_sections',
				'Page Sections',
				'render_custom_sections_meta_box',
				'page',
				'side',
				'default'
			);
		}
	}
	add_action('add_meta_boxes', 'custom_sections_meta_box');

	// Creating fields in a metabox
	function render_custom_sections_meta_box($post) {
		$sections = get_post_meta($post->ID, '_custom_sections', true) ?: [];
		$available_sections = glob(get_template_directory() . '/template-parts/modules/*.php');

		echo '<p>Select modules and drag and drop in the desired order</p>';
		echo '<ul id="sections-list" class="sortable-sections">';

		foreach ($sections as $section) {
			echo '<li class="sortable-item">';
			echo '<select name="custom_sections[]" class="widefat">';
			foreach ($available_sections as $file) {
				$name = basename($file, '.php');
				$selected = ($section === $name) ? 'selected' : '';
				echo "<option value='$name' $selected>$name</option>";
			}
			echo '</select>';
			echo '<button type="button" class="remove-section button-link">✖</button>';
			echo '<button type="button" class="drag-handle">👆</button>';
			echo '</li>';
		}

		echo '</ul>';
		echo '<button type="button" id="add-section" class="button">Add module</button>';

		?>
		<script>
			document.addEventListener('DOMContentLoaded', function () {
				const list = document.getElementById('sections-list');
				const addBtn = document.getElementById('add-section');

				new Sortable(list, {
					handle: '.drag-handle',
					animation: 150,
				});

				addBtn.addEventListener('click', function () {
					let li = document.createElement('li');
					li.classList.add('sortable-item');
					li.innerHTML = `
						<select name="custom_sections[]" class="widefat">
							<?php foreach ($available_sections as $file) {
								$name = basename($file, '.php');
								echo "<option value='$name'>$name</option>";
							} ?>
						</select>
						<button type="button" class="remove-section button-link">✖</button>
						<button type="button" class="drag-handle">👆</button>
					`;
					list.appendChild(li);
				});

				list.addEventListener('click', function (event) {
					if (event.target.classList.contains('remove-section')) {
						event.target.parentElement.remove();
					}
				});
			});
		</script>
		<style>
			#sections-list{list-style-type:none;margin:0 0 15px;padding:0;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif}#sections-list .sortable-item{display:flex;gap:10px;margin-bottom:5px;padding:10px;background-color:#fff;border:1px solid #ccc;border-radius:5px;box-shadow:0 1px 2px rgba(0,0,0,.1)}#sections-list .widefat{width:100%;max-width:300px;min-height: auto;padding:8px;font-size:14px;line-height:1.5;border-radius:4px;background-color:#f7f7f7;border:1px solid #ccc}#sections-list [type=button]{font-size:16px;background-color:transparent;border:none;padding:0}#sections-list .button-link{color:#cc1818}#sections-list .drag-handle{cursor:move}#sections-list+.button{background:#007cba;border:none;padding:6px 12px;font-size:13px;color:#fff}#sections-list+.button:hover{background:#006ba1}
		</style>
		<?php
	}

	// Save metabox data
	function save_custom_sections($post_id) {
		if (!isset($_POST['custom_sections'])) return;
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
		if (!current_user_can('edit_post', $post_id)) return;

		$sections = array_map('sanitize_text_field', $_POST['custom_sections']);
		update_post_meta($post_id, '_custom_sections', $sections);
	}
	add_action('save_post', 'save_custom_sections');

?>