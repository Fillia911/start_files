<?php

	// Remove WordPress version from the header
	remove_action('wp_head', 'wp_generator');

	// Enqueue scripts and styles
	add_action('wp_enqueue_scripts', function() {
		// wp_deregister_script('jquery');
		// wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-3.6.4.min.js', [], null, true);

		wp_enqueue_style('style', get_template_directory_uri() . '/assets/css/main.css', [], filemtime(get_template_directory() . '/assets/css/main.css'));
		wp_enqueue_script('main', get_template_directory_uri() . '/assets/js/jquery.main.js', ['jquery'], filemtime(get_template_directory() . '/assets/js/jquery.main.js'), true);
	});

	// Displays a warning message in the WordPress admin (you can change on Settings -> Reading) if search engine visibility is blocked
	function seo_warning() {
		if( get_option('blog_public') ) return;

		$message = 'You are blocking access to robots. You must go to your <a href="%s">Reading</a> settings and uncheck the box for Search Engine Visibility.';

		echo '<div class="error"><p>';
		printf( $message, admin_url('options-reading.php') );
		echo '</p></div>';
	}
	add_action('admin_notices', 'seo_warning');

	// Theme supports
	add_theme_support('title-tag');
	add_theme_support('custom-logo');
	add_theme_support('post-thumbnails');
	add_theme_support('menus');
	// add_theme_support('custom-background');

	// Disable automatic <p> tags in Contact Form 7 forms
	add_filter('wpcf7_autop_or_not', '__return_false');

	// Disable the large image size threshold in WordPress
	add_filter('big_image_size_threshold', '__return_false');

	// Adds SVG to the list of allowed file uploads
	add_filter('upload_mimes', 'svg_upload_allow');

	function svg_upload_allow( $mimes ) {
		$mimes['svg']  = 'image/svg+xml';
		return $mimes;
	}

	add_filter('wp_check_filetype_and_ext', 'fix_svg_mime_type', 10, 5 );

	function fix_svg_mime_type( $data, $file, $filename, $mimes, $real_mime = ''){

		// WP 5.1 +
		if( version_compare( $GLOBALS['wp_version'], '5.1.0', '>=') ){
			$dosvg = in_array( $real_mime, [ 'image/svg', 'image/svg+xml' ] );
		}
		else {
			$dosvg = ('.svg' === strtolower( substr( $filename, -4 ) ) );
		}

		if( $dosvg ){

			if( current_user_can('manage_options') ){

				$data['ext']  = 'svg';
				$data['type'] = 'image/svg+xml';
			}
			else {
				$data['ext']  = false;
				$data['type'] = false;
			}

		}

		return $data;
	}

	// Disable ACF functions if the ACF plugin is not active and the user is not in the admin panel
	if( !class_exists('acf') && !is_admin() ) {
		function get_field_reference( $field_name, $post_id ) { return ''; }
		function get_field_objects( $post_id = false, $options = array() ) { return false; }
		function get_fields( $post_id = false ) { return false; }
		function get_field( $field_key, $post_id = false, $format_value = true )  { return false; }
		function get_field_object( $field_key, $post_id = false, $options = array() ) { return false; }
		function the_field( $field_name, $post_id = false ) {}
		function have_rows( $field_name, $post_id = false ) { return false; }
		function the_row() {}
		function reset_rows( $hard_reset = false ) {}
		function has_sub_field( $field_name, $post_id = false ) { return false; }
		function get_sub_field( $field_name ) { return false; }
		function the_sub_field( $field_name ) {}
		function get_sub_field_object( $child_name ) { return false;}
		function acf_get_child_field_from_parent_field( $child_name, $parent ) { return false; }
		function register_field_group( $array ) {}
		function get_row_layout() { return false; }
		function acf_form_head() {}
		function acf_form( $options = array() ) {}
		function update_field( $field_key, $value, $post_id = false ) { return false; }
		function delete_field( $field_name, $post_id ) {}
		function create_field( $field ) {}
		function reset_the_repeater_field() {}
		function the_repeater_field( $field_name, $post_id = false ) { return false; }
		function the_flexible_field( $field_name, $post_id = false ) { return false; }
		function acf_filter_post_id( $post_id ) { return $post_id; }
	}

	// Add the ability to duplicate posts and pages
	function duplicate_post_as_draft() {
		global $wpdb;
	
		if (!(isset($_GET['post']) || isset($_POST['post']) || (isset($_REQUEST['action']) && 'duplicate_post_as_draft' === $_REQUEST['action']))) {
			wp_die('No post to duplicate has been supplied!');
		}

		$post_id = (isset($_GET['post']) ? absint($_GET['post']) : absint($_POST['post']));
		$post = get_post($post_id);
	
		if (isset($post) && $post !== null) {
			$new_post = array(
				'post_title'   => $post->post_title . ' (Duplicate)',
				'post_content' => $post->post_content,
				'post_status'  => 'draft',
				'post_type'    => $post->post_type,
				'post_author'  => get_current_user_id(),
			);

			$new_post_id = wp_insert_post($new_post);
	
			$post_meta = get_post_meta($post_id);
			foreach ($post_meta as $key => $values) {
				foreach ($values as $value) {
					add_post_meta($new_post_id, $key, maybe_unserialize($value));
				}
			}
	
			$taxonomies = get_object_taxonomies($post->post_type);
			foreach ($taxonomies as $taxonomy) {
				$post_terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
				wp_set_object_terms($new_post_id, $post_terms, $taxonomy);
			}
	
			wp_redirect(admin_url('post.php?action=edit&post=' . $new_post_id));
			exit;
		} else {
			wp_die('Post creation failed, could not find original post.');
		}
	}
	add_action('admin_action_duplicate_post_as_draft', 'duplicate_post_as_draft');
	
	// Add a “Duplicate” link to the list of posts
	function duplicate_post_link($actions, $post) {
		if (current_user_can('edit_posts')) {
			$actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=duplicate_post_as_draft&post=' . $post->ID, basename(__FILE__), 'duplicate_nonce') . '" title="Duplicate this item" rel="permalink">Duplicate</a>';
		}
		return $actions;
	}
	add_filter('post_row_actions', 'duplicate_post_link', 10, 2);
	add_filter('page_row_actions', 'duplicate_post_link', 10, 2);

?>