<?php

	// Add custom fields to theme customization
	function theme_customize_register($wp_customize) {
		// Header
		$wp_customize->add_section('header_section', array(
			'title'    => 'Header',
			'priority' => 30,
		));

		// Socials Links
		$wp_customize->add_section('social_links_section', array(
			'title'    => 'Socials Links',
			'priority' => 31,
		));

		// Footer
		$wp_customize->add_section('footer_section', array(
			'title'    => 'Footer',
			'priority' => 32,
		));

		$fields = array(
			// Header
			'header_text_01' => array('label' => 'Header Text', 'type' => 'text', 'section' => 'header_section'),
			// Socials Links
			'facebook_link'   => array('label' => 'Facebook Link', 'type' => 'url', 'section' => 'social_links_section'),
			'instagram_link'  => array('label' => 'Instagram Link', 'type' => 'url', 'section' => 'social_links_section'),
			'linkedin_link'   => array('label' => 'Linkedin Link', 'type' => 'url', 'section' => 'social_links_section'),
			// Footer
			'footer_text_01'  => array('label' => 'Footer Text', 'type' => 'textarea', 'section' => 'footer_section'),
		);

		foreach ($fields as $id => $field) {
			$wp_customize->add_setting($id, array(
				'default'           => '',
				'sanitize_callback' => $field['type'] === 'textarea' ? 'wp_kses_post' : ($field['type'] === 'text' ? 'sanitize_text_field' : 'esc_url_raw'),
			));
	
			$wp_customize->add_control($id, array(
				'label'    => $field['label'],
				'section'  => $field['section'],
				'settings' => $id,
				'type'     => $field['type'],
			));
		}
	}
	add_action('customize_register', 'theme_customize_register');

	// Create socials list
	function social_icons($type = 'images') {
		$socials = array(
			'facebook'   => get_theme_mod('facebook_link', ''),
			'instagram'  => get_theme_mod('instagram_link', ''),
			'linkedin'   => get_theme_mod('linkedin_link', ''),
		);
	
		$theme_url = get_template_directory_uri();
		$output = '<ul class="socials-list">';
	
		foreach ($socials as $name => $url) {
			if (!empty($url)) {
				if ($type === 'icons') {
					$output .= sprintf(
						'<li><a href="%s" target="_blank" rel="noopener noreferrer"><i class="ico-%s"></i></a></li>',
						esc_url($url),
						esc_attr($name)
					);
				} else {
					$output .= sprintf(
						'<li><a href="%s" target="_blank" rel="noopener noreferrer"><img src="%s/assets/images/ico-%s.svg" alt="ico-%s"></a></li>',
						esc_url($url),
						esc_url($theme_url),
						esc_attr($name),
						esc_attr($name)
					);
				}
			}
		}
	
		$output .= '</ul>';
		echo $output;
	}

?>
