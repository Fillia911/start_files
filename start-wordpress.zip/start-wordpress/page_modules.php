<?php
/*
Template Name: Modules Template
*/
get_header();
?>

<?php
	$sections = get_post_meta(get_the_ID(), '_custom_sections', true);
	if (!empty($sections) && is_array($sections)) {
		foreach ($sections as $section) {
			$file = get_template_directory() . '/template-parts/modules/' . $section . '.php';
			if (file_exists($file)) {
				include $file;
			}
		}
	}
?>

<?php get_footer(); ?>