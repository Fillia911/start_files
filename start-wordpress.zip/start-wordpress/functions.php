<?php

	// Default theme settings
	include( get_template_directory() . '/includes/default.php' );

	// Drag-and-drop sections
	include( get_template_directory() . '/includes/modules_template.php' );

	// Theme additional custom field
	include( get_template_directory() . '/includes/theme_custom_fields.php' );

	// Menu settings
	include( get_template_directory() . '/includes/menus.php' );

	// Custom functions
	include( get_template_directory() . '/includes/custom_functions.php' );

?>