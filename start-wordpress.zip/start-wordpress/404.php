<?php get_header(); ?>

	<section class="theme_content-section">
		<div class="container">
			<?php get_template_part( 'template-parts/not_found' ); ?>
		</div>
	</section>

<?php get_footer(); ?>