<?php get_header(); ?>

<section class="wp_theme-section">
    <div class="container">
        <div class="title-holder">
            <h1>Search results for: <?php echo get_search_query(); ?></h1>
        </div>

        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article>
                    <h2>
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h2>
                    <?php the_excerpt(); ?>
                </article>
            <?php endwhile; ?>
        <?php else : ?>
            <p>No results found.</p>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>