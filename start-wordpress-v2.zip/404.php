<?php get_header(); ?>

<section class="wp_theme-section">
    <div class="container">
        <div class="title-holder">
            <h1>Error 404</h1>
            <p>Page not found.</p>
        </div>

        <?php get_search_form(); ?>
    </div>
</section>

<?php get_footer(); ?>