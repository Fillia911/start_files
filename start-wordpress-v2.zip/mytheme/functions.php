<?php
// Theme Setup
require get_template_directory() . '/includes/setup.php';

// Navigation Menus
require get_template_directory() . '/includes/navigation.php';

// Theme Custom Fields
require get_template_directory() . '/includes/customizer.php';

// Custom Functions
require get_template_directory() . '/includes/extras.php';