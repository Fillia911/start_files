<?php
// ===========================
// Theme Setup
// ===========================
function theme_setup() {

    // Automatic <title>
    add_theme_support('title-tag');

    // Custom logo
    add_theme_support('custom-logo');

    // Post thumbnails
    add_theme_support('post-thumbnails');

    // HTML5 support
    add_theme_support('html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script'
    ]);

    // Sidebar
    register_sidebar([
        'name'          => 'Sidebar',
        'id'            => 'sidebar-1',
        'description'   => 'Main Sidebar',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ]);
}
add_action('after_setup_theme', 'theme_setup');

// ===========================
// Enqueue Styles and Scripts
// ===========================
function theme_enqueue_assets() {
    // Main style.css (required by WP)
    wp_enqueue_style('style', get_stylesheet_uri());

    // Main CSS with cache busting
    wp_enqueue_style(
        'main', get_template_directory_uri() . '/assets/css/main.css', [], filemtime(get_template_directory() . '/assets/css/main.css')
    );

    // ===========================
    // JQUERY
    // Uncomment below to load latest version from CDN:
    // wp_deregister_script('jquery');
    // wp_enqueue_script(
    //     'jquery', 'https://code.jquery.com/jquery-3.6.4.min.js', [], null, true
    // );
    // ===========================

    // Main JS
    wp_enqueue_script(
        'main', get_template_directory_uri() . '/assets/js/main.js', ['jquery'], filemtime(get_template_directory() . '/assets/js/main.js'), true
    );
}
add_action('wp_enqueue_scripts', 'theme_enqueue_assets');

// ===========================
// SEO / Security
// ===========================

// Remove WP version from <head>
remove_action('wp_head', 'wp_generator');

// Search engine visibility warning
function theme_seo_warning() {
    if (get_option('blog_public')) return;

    $message = 'Attention! Search is disabled. Go to <a href="%s">Settings → Reading</a> and uncheck "Discourage search engines from indexing this site".';
    echo '<div class="error"><p>';
    printf($message, admin_url('options-reading.php'));
    echo '</p></div>';
}
add_action('admin_notices', 'theme_seo_warning');

// ===========================
// Optimization
// ===========================

// Disable automatic <p> in Contact Form 7
add_filter('wpcf7_autop_or_not', '__return_false'); 

// Disable big image size threshold
add_filter('big_image_size_threshold', '__return_false');

// ===========================
// SVG Upload
// ===========================
function theme_allow_svg($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'theme_allow_svg');

function theme_fix_svg_mime($data, $file, $filename, $mimes, $real_mime = '') {
    $is_svg = version_compare($GLOBALS['wp_version'], '5.1.0', '>=') 
        ? in_array($real_mime, ['image/svg', 'image/svg+xml']) 
        : ('.svg' === strtolower(substr($filename, -4)));

    if ($is_svg) {
        if (current_user_can('manage_options')) {
            $data['ext']  = 'svg';
            $data['type'] = 'image/svg+xml';
        } else {
            $data['ext']  = false;
            $data['type'] = false;
        }
    }
    return $data;
}
add_filter('wp_check_filetype_and_ext', 'theme_fix_svg_mime', 10, 5);

// ===========================
// ACF Fallback (if plugin inactive)
// ===========================
if (!class_exists('acf') && !is_admin()) {
    function get_field_reference($field_name, $post_id) { return ''; }
    function get_field_objects($post_id = false, $options = []) { return false; }
    function get_fields($post_id = false) { return false; }
    function get_field($field_key, $post_id = false, $format_value = true) { return false; }
    function get_field_object($field_key, $post_id = false, $options = []) { return false; }
    function the_field($field_name, $post_id = false) {}
    function have_rows($field_name, $post_id = false) { return false; }
    function the_row() {}
    function reset_rows($hard_reset = false) {}
    function has_sub_field($field_name, $post_id = false) { return false; }
    function get_sub_field($field_name) { return false; }
    function the_sub_field($field_name) {}
    function get_sub_field_object($child_name) { return false;}
    function acf_get_child_field_from_parent_field($child_name, $parent) { return false; }
    function register_field_group($array) {}
    function get_row_layout() { return false; }
    function acf_form_head() {}
    function acf_form($options = []) {}
    function update_field($field_key, $value, $post_id = false) { return false; }
    function delete_field($field_name, $post_id) {}
    function create_field($field) {}
    function reset_the_repeater_field() {}
    function the_repeater_field($field_name, $post_id = false) { return false; }
    function the_flexible_field($field_name, $post_id = false) { return false; }
    function acf_filter_post_id($post_id) { return $post_id; }
}

// ===========================
// Duplicate Posts
// ===========================
function theme_duplicate_post_as_draft() {
    if (!isset($_GET['post']) && !isset($_POST['post'])) {
        wp_die('No post ID provided for duplication!');
    }

    $post_id = isset($_GET['post']) ? absint($_GET['post']) : absint($_POST['post']);
    $post = get_post($post_id);

    if ($post) {
        $new_post = [
            'post_title'   => $post->post_title . ' (Copy)',
            'post_content' => $post->post_content,
            'post_status'  => 'draft',
            'post_type'    => $post->post_type,
            'post_author'  => get_current_user_id(),
        ];

        $new_post_id = wp_insert_post($new_post);

        // Copy post meta
        $post_meta = get_post_meta($post_id);
        foreach ($post_meta as $key => $values) {
            foreach ($values as $value) {
                add_post_meta($new_post_id, $key, maybe_unserialize($value));
            }
        }

        // Copy taxonomies
        $taxonomies = get_object_taxonomies($post->post_type);
        foreach ($taxonomies as $taxonomy) {
            $terms = wp_get_object_terms($post_id, $taxonomy, ['fields' => 'slugs']);
            wp_set_object_terms($new_post_id, $terms, $taxonomy);
        }

        wp_redirect(admin_url('post.php?action=edit&post=' . $new_post_id));
        exit;
    } else {
        wp_die('Error: Original post not found.');
    }
}
add_action('admin_action_duplicate_post_as_draft', 'theme_duplicate_post_as_draft');

function theme_duplicate_post_link($actions, $post) {
    if (current_user_can('edit_posts')) {
        $actions['duplicate'] = '<a href="' . wp_nonce_url(
            'admin.php?action=duplicate_post_as_draft&post=' . $post->ID,
            basename(__FILE__),
            'duplicate_nonce'
        ) . '" title="Duplicate this post">Duplicate</a>';
    }
    return $actions;
}
add_filter('post_row_actions', 'theme_duplicate_post_link', 10, 2);
add_filter('page_row_actions', 'theme_duplicate_post_link', 10, 2);