        </main>

        <footer id="footer">
            <!-- Code Here -->
        </footer>
    </div>

    <?php wp_footer(); ?>
</body>
</html>
