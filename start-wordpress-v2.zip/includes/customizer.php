<?php
// ===========================
// Register Customizer Fields
// ===========================
function theme_customize_register($wp_customize) {

    // Sections
    $sections = [
        'header_section'       => ['title' => 'Header', 'priority' => 30],
        'social_links_section' => ['title' => 'Social Links', 'priority' => 31],
        'footer_section'       => ['title' => 'Footer', 'priority' => 32],
    ];

    foreach ($sections as $id => $args) {
        $wp_customize->add_section($id, $args);
    }

    // Fields
    $fields = [
        // Header
        'header_text_01' => ['label' => 'Header Text', 'type' => 'text', 'section' => 'header_section'],

        // Socials
        'facebook_link'  => ['label' => 'Facebook Link', 'type' => 'url', 'section' => 'social_links_section'],
        'instagram_link' => ['label' => 'Instagram Link', 'type' => 'url', 'section' => 'social_links_section'],
        'linkedin_link'  => ['label' => 'LinkedIn Link', 'type' => 'url', 'section' => 'social_links_section'],

        // Footer
        'footer_text_01' => ['label' => 'Footer Text', 'type' => 'textarea', 'section' => 'footer_section'],
    ];

    $sanitize_callbacks = [
        'text'     => 'sanitize_text_field',
        'url'      => 'esc_url_raw',
        'textarea' => 'wp_kses_post',
        'image'    => 'esc_url_raw',
        'email'    => 'sanitize_email',
        'number'   => 'absint',
        'color'    => 'sanitize_hex_color',
    ];

    foreach ($fields as $id => $field) {

        $sanitize = $sanitize_callbacks[ $field['type'] ] ?? 'sanitize_text_field';

        $wp_customize->add_setting($id, [
            'default'           => '',
            'sanitize_callback' => $sanitize,
        ]);

        if ($field['type'] === 'image') {
            $wp_customize->add_control(
                new WP_Customize_Image_Control(
                    $wp_customize,
                    $id,
                    [
                        'label'    => $field['label'],
                        'section'  => $field['section'],
                        'settings' => $id,
                    ]
                )
            );
        } else {
            $wp_customize->add_control($id, [
                'label'    => $field['label'],
                'section'  => $field['section'],
                'settings' => $id,
                'type'     => $field['type'],
            ]);
        }
    }
}
add_action('customize_register', 'theme_customize_register');

/*
Examples:
echo wp_kses_post(get_theme_mod('header_text_01'));   // get header text
echo esc_url(get_theme_mod('facebook_link'));         // get facebook link
*/

// ===========================
// Social Icons Output
// ===========================
function social_icons($type = 'images') {
    $socials = [
        'facebook'  => get_theme_mod('facebook_link', ''),
        'instagram' => get_theme_mod('instagram_link', ''),
        'linkedin'  => get_theme_mod('linkedin_link', ''),
    ];

    if (empty(array_filter($socials))) {
        return;
    }

    $theme_url = get_template_directory_uri();
    $output = '<ul class="socials-list">';

    foreach ($socials as $name => $url) {
        if (!$url) continue;

        if ($type === 'icons') {
            // Use icon fonts
            $output .= sprintf(
                '<li><a href="%s" target="_blank" rel="noopener noreferrer"><i class="ico-%s"></i></a></li>',
                esc_url($url),
                esc_attr($name)
            );
        } else {
            // Use SVG images
            $output .= sprintf(
                '<li><a href="%s" target="_blank" rel="noopener noreferrer"><img src="%s/assets/images/ico-%s.svg" alt="%s"></a></li>',
                esc_url($url),
                esc_url($theme_url),
                esc_attr($name),
                ucfirst($name)
            );
        }
    }

    $output .= '</ul>';
    echo $output;
}

/*
Examples:
<?php social_icons('icons'); ?>   // output as font icons
<?php social_icons(); ?>          // output default SVG images
*/