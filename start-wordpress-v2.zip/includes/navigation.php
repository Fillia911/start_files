<?php
// ===========================
// Register Navigation Menus
// ===========================
add_action('after_setup_theme', function() {
    register_nav_menus([
        'primary' => 'Primary Navigation',
        'footer'  => 'Footer Navigation',
    ]);
});

/*
Examples:
wp_nav_menu([
    'theme_location' => 'primary',
    'menu_class'     => 'main-menu',
    'container'      => 'nav',
]);
*/

// ===========================
// Custom Walker for Menu
// ===========================
class Custom_Walker_Nav_Menu extends Walker_Nav_Menu {
    
    // Start menu item
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? [] : (array) $item->classes;
        $class_names = implode(' ', array_filter($classes));

        $output .= '<li id="menu-item-'. $item->ID .'" class="' . esc_attr($class_names) . '">';

        $aria_current = in_array('current-menu-item', $classes) ? ' aria-current="page"' : '';
        $output .= '<a href="' . esc_url($item->url) . '"' . $aria_current . '>';
        $output .= esc_html($item->title);

        if (in_array('menu-item-has-children', $classes)) {
            $output .= '<span class="submenu-toggle" aria-hidden="true"></span>';
        }

        $output .= '</a>';
    }

    function start_lvl(&$output, $depth = 0, $args = null) {
        $output .= '<ul class="sub-menu">';
    }

    function end_el(&$output, $item, $depth = 0, $args = null) {
        $output .= '</li>';
    }
}

/*
Examples:
wp_nav_menu([
    'theme_location' => 'primary',
    'menu_class'     => 'main-menu',
    'container'      => 'nav',
    'walker'         => new Custom_Walker_Nav_Menu(),
]);

wp_nav_menu([
    'theme_location' => 'primary',
    'menu_class'     => 'main-menu',
    'container'      => 'nav',
]);
*/