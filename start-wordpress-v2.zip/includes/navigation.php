<?php
// ===========================
// Register Navigation Menus
// ===========================
add_action('after_setup_theme', function() {
    register_nav_menus([
        'primary' => 'Primary Navigation',
        'footer'  => 'Footer Navigation',
    ]);
});

// ===========================
// Custom Walker for Menu
// ===========================
class Custom_Walker_Nav_Menu extends Walker_Nav_Menu {
    
    public function start_lvl( &$output, $depth = 0, $args = null ) {
        $output .= '<ul class="menu-children-wrapper">';
    }

    public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {

        $depth_class = 'menu-depth-' . ($depth + 1);
        $output .= '<li class="' . esc_attr($depth_class) . '">';

        $url = trim($item->url);
        if ($url === '') {
            $output .= '<a href="javascript:;">' . esc_html($item->title) . '</a>';
        } else {
            $output .= '<a href="' . esc_url($url) . '">' . esc_html($item->title) . '</a>';
        }
    }

    public function end_el( &$output, $item, $depth = 0, $args = null ) {
        $output .= '</li>';
    }
}

/*
Examples:
wp_nav_menu([
    'theme_location' => 'primary',
    'menu_class'     => 'menu-list',
    'container'      => 'nav',
    'walker'         => new Custom_Walker_Nav_Menu(),
]);

wp_nav_menu([
    'theme_location' => 'primary',
    'menu_class'     => 'menu-list',
    'container'      => 'nav',
]);
*/