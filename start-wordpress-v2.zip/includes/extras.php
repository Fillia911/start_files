<?php
// ===========================
// Custom Theme Functions
// ===========================

// Get post reading time (words per minute can be set)
function get_post_reading_time($words_per_minute = 200, $echo = true) {
    $content = get_the_content();
    $word_count = str_word_count(strip_tags($content));
    $reading_time = ceil($word_count / $words_per_minute);

    $output = $reading_time ? '<span class="post-reading-time">' . $reading_time . ' min read</span>' : '';
    if ($echo) {
        echo $output;
    } else {
        return $output;
    }
}

/*
Examples:
get_post_reading_time();                 // default 200 wpm
get_post_reading_time(300);              // 300 wpm
echo get_post_reading_time(250, false);  // return as string

$reading_time = get_post_reading_time(250, false);
echo '<div class="reading-time">Estimated: ' . $reading_time . '</div>';
*/

// Get post categories
function get_post_categories($echo = true) {
    $categories_list = get_the_category_list(', ');
    $output = $categories_list ? '<span class="post-categories">' . $categories_list . '</span>' : '';
    if ($echo) {
        echo $output;
    } else {
        return $output;
    }
}

/*
Examples:
get_post_categories();                              // echo categories
$cats = get_post_categories(false);                 // return as string
echo '<div class="post-cats">' . $cats . '</div>';
*/

// Custom post date with archive link option
function custom_date_info($show_link = false, $show_time = true, $date_format = 'F jS, Y', $echo = true) {
    $year  = get_the_date('Y');
    $month = get_the_date('m');
    $day   = get_the_date('d');

    $archive_type = get_option('eg_date_archive_link_type', 'month');
    switch ($archive_type) {
        case 'year':
            $archive_link = get_year_link($year);
            break;
        case 'day':
            $archive_link = get_day_link($year, $month, $day);
            break;
        default:
            $archive_link = get_month_link($year, $month);
            break;
    }

    $time_string = sprintf(
        '<time class="entry-date published updated" datetime="%1$s">%2$s</time>',
        esc_attr(get_the_date('c')),
        esc_html(date_i18n($date_format, get_the_date('U')))
    );

    if ($show_link) {
        $output = '<a href="' . esc_url($archive_link) . '" rel="bookmark">' . $time_string . '</a>';
    } elseif ($show_time) {
        $output = $time_string;
    } else {
        $output = '';
    }

    if ($echo) {
        echo $output;
    } else {
        return $output;
    }
}

/*
Examples:
custom_date_info();                                          // echo date
custom_date_info(true);                                      // echo date with archive link
$date_str = custom_date_info(false, true, 'F j, Y', false);  // return as string
*/

// Clean phone number
function clean_phone($phone, $echo = true) {
    $cleaned_phone = preg_replace('/[^0-9]/', '', $phone);
    if ($echo) {
        echo $cleaned_phone;
    } else {
        return $cleaned_phone;
    }
}

/*
Examples:
clean_phone('(123) 456-7890');                   // echo 1234567890
$phone = clean_phone('+1 234 567 8900', false);
echo '<div class="phone">' . $phone . '</div>';
*/

// Trim any text to a certain number of words
function trim_text($text, $length = 20, $echo = true) {
    $trimmed = wp_trim_words($text, $length, '...');
    if ($echo) {
        echo $trimmed;
    } else {
        return $trimmed;
    }
}

/*
Examples:
$text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
trim_text($text);                                          // default 20 words
trim_text($text, 10);                                      // 10 words
$short_text = trim_text($text, 15, false);
echo '<div class="short-text">' . $short_text . '</div>';
*/